package Faccat;

import java.util.Scanner;

public class Codigo14 {

	public static void main(String[] args) {

		int valor = 0;

		Scanner sc = new Scanner(System.in);

		System.out.printf("Digite um valor númerico: ",+valor);

		valor=sc.nextInt();
		if(valor>10) {
			System.out.println("O valor é maior que 10");
		}
		else {
			System.out.println("O valor é menor que 10");
		}





	}




}

